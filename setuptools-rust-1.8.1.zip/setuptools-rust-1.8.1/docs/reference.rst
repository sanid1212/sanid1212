API Reference
=============

.. py:module:: setuptools_rust

.. autoclass:: RustExtension
.. autoclass:: RustBin
.. autoclass:: Binding
.. autoclass:: Strip
